#!/bin/bash

#/* ************************************************************************
#   Computation of graph hitting time moments; Chapel code implementation.
#   by Sandia National Laboratories
#
#   Copyright 2020 National Technology & Engineering Solutions of Sandia, LLC (NTESS).
#   Under the terms of Contract DE-NA0003525 with NTESS, the U.S. Government retains
#   certain rights in this software.
#
#   Permission is hereby granted, free of charge, to any person obtaining a copy
#   of this software and associated documentation files (the "Software"), to deal
#   in the Software without restriction, including without limitation the rights
#   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#   copies of the Software, and to permit persons to whom the Software is furnished
#   to do so, subject to the following conditions:
#
#   The above copyright notice and this permission notice shall be included in
#   all copies or substantial portions of the Software.
#
#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
#   INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
#   PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
#   HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
#   OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
#   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#   ************************************************************************ */

set -x

export GASNET_SPAWNFN='L'

EXEC=xHTM

ARCH=osx

BLAS=false

BALANCE=false

CODE_LOC=~/laposta_dist

EXEC_LOC=$CODE_LOC/bin/$ARCH

num_locales="1 2 4"

num_vertices="1000" # 5000 10000 100000"

INPUT_MATRIX_SOURCE="banded"
 
MAX_VERTEX_DEGREE=6
MATRIX_SEED=7

MATRIX_FORMAT="COO"                     

HITTING_SET_NUM_VERTICES=7
HITTING_SET_SEED=23

SOLVER="cg"                              # cg
PRECONDITIONER="jacobi"                  # jacobi
TOLERANCE=.0001                          # SOLVER error tolerance.

### End input parameters

$EXEC_LOC/$EXEC --about

for NUM_LOCALES in $num_locales; do
for NUM_VERTICES in $num_vertices; do

   MAX_ITERATIONS=$((NUM_VERTICES / 2))

   $EXEC_LOC/$EXEC \
	--verbose \
        --numLocales                $NUM_LOCALES \
        --blas=$BLAS \
        --load_balance=$BALANCE \
        --input_matrix_source       $INPUT_MATRIX_SOURCE \
        --num_vertices              $NUM_VERTICES \
        --max_vertex_degree         $MAX_VERTEX_DEGREE \
        --matrix_seed               $MATRIX_SEED \
        --matrix_format             $MATRIX_FORMAT \
        --hitting_set_num_vertices  $HITTING_SET_NUM_VERTICES \
        --hitting_set_seed          $HITTING_SET_SEED \
        --solver                    $SOLVER \
        --preconditioner            $PRECONDITIONER \
        --max_iterations            $MAX_ITERATIONS \
        --tolerance                 $TOLERANCE

done
done

# End HTM input deck.
